<?php

defined( 'ABSPATH' ) || exit;

final class Fant_Admin_API_V4_REST {
	private const API_NAMESPACE = 'fant-admin/v1';
	private const MAX_LOGIN_ATTEMPTS = 5;
	private const LOGIN_WINDOW = 900;

	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_cors' ), 15 );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'handle_preflight' ), 10, 3 );
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'allow_options_without_auth' ), 20 );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'attach_cors_to_response' ), 10, 3 );
	}

	/**
	 * Le preflight OPTIONS non devono richiedere Bearer token.
	 *
	 * @param mixed $result
	 * @return mixed
	 */
	public static function allow_options_without_auth( $result ) {
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'OPTIONS' === strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) && self::request_uri_is_fant_admin() ) {
			return true;
		}
		return $result;
	}

	public static function register_cors(): void {
		// Serve la risposta dopo aver pulito eventuali BOM/output prematuri
		// che impediscono di impostare Access-Control-* (sintomo: Content-Type text/html).
		add_filter( 'rest_pre_serve_request', array( __CLASS__, 'serve_with_cors' ), 5, 4 );
	}

	/**
	 * @param WP_HTTP_Response $response
	 * @param WP_REST_Server   $server
	 * @param WP_REST_Request  $request
	 * @return WP_HTTP_Response
	 */
	public static function attach_cors_to_response( $response, $server, $request ) {
		if ( ! ( $request instanceof WP_REST_Request ) || ! self::is_fant_admin_request( $request ) ) {
			return $response;
		}
		if ( ! ( $response instanceof WP_HTTP_Response ) ) {
			return $response;
		}

		$origin = self::allowed_origin();
		if ( '' === $origin ) {
			return $response;
		}

		$response->header( 'Access-Control-Allow-Origin', $origin );
		$response->header( 'Access-Control-Allow-Credentials', 'true' );
		$response->header( 'Access-Control-Allow-Methods', 'OPTIONS, GET, POST, PUT, PATCH, DELETE' );
		$response->header( 'Access-Control-Allow-Headers', 'Authorization, Content-Type, X-WP-Nonce, X-Requested-With, Accept' );
		$response->header( 'Access-Control-Expose-Headers', 'X-WP-Total, X-WP-TotalPages' );
		$response->header( 'Access-Control-Max-Age', '600' );
		$response->header( 'Vary', 'Origin', false );

		return $response;
	}

	/**
	 * Risponde alle preflight OPTIONS per fant-admin/v1 (Authorization da Angular).
	 *
	 * @param mixed           $result
	 * @param WP_REST_Server  $server
	 * @param WP_REST_Request $request
	 * @return mixed|WP_REST_Response
	 */
	public static function handle_preflight( $result, $server, $request ) {
		if ( ! self::is_fant_admin_request( $request ) ) {
			return $result;
		}

		if ( 'OPTIONS' === $request->get_method() ) {
			$response = new WP_REST_Response( null, 204 );
			$response = self::attach_cors_to_response( $response, $server, $request );
			$response->header( 'Content-Length', '0' );
			return $response;
		}

		return $result;
	}

	/**
	 * @param bool             $served
	 * @param WP_HTTP_Response $result
	 * @param WP_REST_Request  $request
	 * @param WP_REST_Server   $server
	 * @return bool
	 */
	public static function serve_with_cors( $served, $result, $request, $server ) {
		if ( ! ( $request instanceof WP_REST_Request ) || ! self::is_fant_admin_request( $request ) ) {
			return $served;
		}

		// Rimuove output accidentale (BOM UTF-8, whitespace) già inviato da altri file.
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		$result = self::attach_cors_to_response( $result, $server, $request );

		// Replica il serve nativo WP ma dopo aver pulito i buffer.
		$origin = self::allowed_origin();
		if ( '' !== $origin && ! headers_sent() ) {
			header( 'Access-Control-Allow-Origin: ' . $origin );
			header( 'Access-Control-Allow-Credentials: true' );
			header( 'Access-Control-Allow-Methods: OPTIONS, GET, POST, PUT, PATCH, DELETE' );
			header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Requested-With, Accept' );
			header( 'Access-Control-Expose-Headers: X-WP-Total, X-WP-TotalPages' );
			header( 'Access-Control-Max-Age: 600' );
			header( 'Vary: Origin', false );
		}

		if ( ! headers_sent() ) {
			header( 'Content-Type: application/json; charset=UTF-8' );
		}

		$data = $result->get_data();
		$json = wp_json_encode( $data );
		if ( false === $json ) {
			$status = $result->get_status();
			status_header( $status ? (int) $status : 500 );
			echo '{"code":"faa_json_encode_failed","message":"Impossibile serializzare la risposta.","data":{"status":500}}';
			return true;
		}

		$status = $result->get_status();
		if ( $status ) {
			status_header( (int) $status );
		}

		foreach ( $result->get_headers() as $key => $value ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $item ) {
					header( sprintf( '%s: %s', $key, $item ), false );
				}
			} else {
				header( sprintf( '%s: %s', $key, $value ) );
			}
		}

		echo $json;
		return true;
	}

	private static function allowed_origin(): string {
		$origin = get_http_origin();
		if ( ! is_string( $origin ) || '' === $origin ) {
			$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? trim( wp_unslash( (string) $_SERVER['HTTP_ORIGIN'] ) ) : '';
		}
		if ( '' === $origin || 'null' === $origin ) {
			return '';
		}

		/**
		 * Origini CORS aggiuntive. Di default si riflette qualsiasi Origin
		 * (come fa WordPress REST), perché le route sono già protette da auth admin.
		 *
		 * @param string[] $allowed
		 * @param string   $origin
		 */
		$allowed = apply_filters( 'faa_cors_allowed_origins', array( '*' ), $origin );
		if ( ! is_array( $allowed ) ) {
			$allowed = array( '*' );
		}

		if ( in_array( '*', $allowed, true ) ) {
			return $origin;
		}

		foreach ( $allowed as $candidate ) {
			if ( is_string( $candidate ) && 0 === strcasecmp( rtrim( $candidate, '/' ), rtrim( $origin, '/' ) ) ) {
				return $origin;
			}
		}

		return '';
	}

	private static function is_fant_admin_request( WP_REST_Request $request ): bool {
		$route = (string) $request->get_route();
		return str_starts_with( $route, '/' . self::API_NAMESPACE );
	}

	private static function request_uri_is_fant_admin(): bool {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		return false !== strpos( $uri, '/wp-json/' . self::API_NAMESPACE );
	}

	public static function register_routes(): void {
		self::route( '/status', WP_REST_Server::READABLE, 'status', '__return_true' );
		self::route( '/auth/login', WP_REST_Server::CREATABLE, 'login', '__return_true' );
		self::route( '/auth/refresh', WP_REST_Server::CREATABLE, 'refresh', '__return_true' );
		self::route( '/auth/logout', WP_REST_Server::CREATABLE, 'logout', '__return_true' );
		self::route( '/me', WP_REST_Server::READABLE, 'me' );

		register_rest_route(
			self::API_NAMESPACE,
			'/categories',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'categories' ),
					'permission_callback' => array( __CLASS__, 'authorized' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_category' ),
					'permission_callback' => array( __CLASS__, 'authorized' ),
				),
			)
		);
		self::route( '/categories/reorder', 'PUT', 'reorder_categories' );
		self::route( '/categories/(?P<categoryId>\d+)', 'PUT', 'update_category' );
		self::route( '/categories/(?P<categoryId>\d+)', WP_REST_Server::DELETABLE, 'delete_category' );

		register_rest_route(
			self::API_NAMESPACE,
			'/catalogs',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'catalogs' ),
					'permission_callback' => array( __CLASS__, 'authorized' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_catalog' ),
					'permission_callback' => array( __CLASS__, 'authorized' ),
				),
			)
		);
		self::route( '/catalogs/(?P<catalogCode>[a-zA-Z0-9_-]+)/contenuto', 'PUT', 'update_catalog_contenuto' );
		self::route( '/catalogs/(?P<catalogCode>[a-zA-Z0-9_-]+)/settings', 'PUT', 'update_catalog_settings' );
		self::route( '/catalogs/(?P<catalogCode>[a-zA-Z0-9_-]+)', WP_REST_Server::READABLE, 'catalog' );
		self::route( '/catalogs/(?P<catalogCode>[a-zA-Z0-9_-]+)', 'PUT', 'update_catalog' );
		self::route( '/catalogs/(?P<catalogCode>[a-zA-Z0-9_-]+)', WP_REST_Server::DELETABLE, 'delete_catalog' );

		register_rest_route(
			self::API_NAMESPACE,
			'/covers',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'covers' ),
					'permission_callback' => array( __CLASS__, 'authorized' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_cover' ),
					'permission_callback' => array( __CLASS__, 'authorized' ),
				),
			)
		);
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)', WP_REST_Server::READABLE, 'cover' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)', 'PUT', 'update_cover' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)', WP_REST_Server::DELETABLE, 'delete_cover' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)/attachments', WP_REST_Server::CREATABLE, 'upload_cover_attachments' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)/attachments/(?P<fileName>[^/]+)', 'PUT', 'update_cover_attachment' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)/attachments/(?P<fileName>[^/]+)', WP_REST_Server::DELETABLE, 'delete_cover_attachment' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)/articoli', 'PUT', 'update_cover_articoli' );
		self::route( '/covers/(?P<coverCode>[a-zA-Z0-9_-]+)/pdf', WP_REST_Server::READABLE, 'cover_pdf' );

		self::route( '/layouts', WP_REST_Server::READABLE, 'layouts' );
		self::route( '/layouts/(?P<layoutCode>[a-zA-Z0-9_-]+)', WP_REST_Server::READABLE, 'layout' );
		self::route( '/layouts/(?P<layoutCode>[a-zA-Z0-9_-]+)', 'PUT', 'update_layout' );

		self::route( '/settings/ai', WP_REST_Server::READABLE, 'ai_settings' );
		self::route( '/settings/ai', 'PUT', 'update_ai_settings' );

		self::route( '/products', WP_REST_Server::READABLE, 'products' );
	}

	private static function route( string $path, string $methods, string $callback, $permission = null ): void {
		register_rest_route(
			self::API_NAMESPACE,
			$path,
			array(
				'methods'             => $methods,
				'callback'            => array( __CLASS__, $callback ),
				'permission_callback' => $permission ?: array( __CLASS__, 'authorized' ),
			)
		);
	}

	public static function status(): WP_REST_Response {
		$hpos_enabled = false;
		if ( class_exists( Automattic\WooCommerce\Utilities\OrderUtil::class ) ) {
			$hpos_enabled = Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		}

		return new WP_REST_Response(
			array(
				'name'        => 'fantAdminApi',
				'version'     => FANT_ADMIN_API_V4_VERSION,
				'woocommerce' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
				'hposEnabled' => $hpos_enabled,
			),
			200
		);
	}

	public static function authorized() {
		$user = wp_get_current_user();
		if ( ! $user->exists() ) {
			return self::error( 'unauthorized', 'Token assente, non valido o scaduto.', 401 );
		}

		if ( ! Fant_Admin_API_V4_Auth::is_administrator( $user ) ) {
			return self::error( 'administrator_required', 'Accesso riservato agli amministratori.', 403 );
		}

		return true;
	}

	public static function login( WP_REST_Request $request ) {
		Fant_Admin_API_V4_Install::ensure_installed();

		$login       = trim( sanitize_text_field( (string) $request->get_param( 'login' ) ) );
		$password    = (string) $request->get_param( 'password' );
		$device_id   = sanitize_text_field( (string) $request->get_param( 'deviceId' ) );
		$device_name = sanitize_text_field( (string) $request->get_param( 'deviceName' ) );

		if ( '' === $login || '' === $password ) {
			return self::error( 'invalid_login_request', 'Username/email e password sono obbligatori.', 422 );
		}

		$rate_key = self::rate_limit_key( $login );
		$attempts = (int) get_transient( $rate_key );
		if ( $attempts >= self::MAX_LOGIN_ATTEMPTS ) {
			return self::error( 'too_many_attempts', 'Troppi tentativi. Riprova tra alcuni minuti.', 429 );
		}

		$user = wp_authenticate( $login, $password );
		if ( is_wp_error( $user ) ) {
			set_transient( $rate_key, $attempts + 1, self::LOGIN_WINDOW );
			return self::error( 'invalid_credentials', 'Credenziali non valide.', 401 );
		}

		if ( ! Fant_Admin_API_V4_Auth::is_administrator( $user ) ) {
			set_transient( $rate_key, $attempts + 1, self::LOGIN_WINDOW );
			return self::error( 'administrator_required', 'Accesso riservato agli amministratori.', 403 );
		}

		delete_transient( $rate_key );

		try {
			$tokens = Fant_Admin_API_V4_Auth::issue( (int) $user->ID, $device_id, $device_name );
		} catch ( Throwable $exception ) {
			return self::error( 'session_error', 'Impossibile creare la sessione.', 500 );
		}

		return rest_ensure_response( array_merge( $tokens, array( 'user' => self::user_data( $user ) ) ) );
	}

	public static function refresh( WP_REST_Request $request ) {
		$refresh_token = (string) $request->get_param( 'refreshToken' );
		$user          = '' !== $refresh_token ? Fant_Admin_API_V4_Auth::user_for_refresh_token( $refresh_token ) : null;

		if ( ! $user ) {
			return self::error( 'invalid_refresh_token', 'Refresh token non valido o scaduto.', 401 );
		}

		if ( ! Fant_Admin_API_V4_Auth::is_administrator( $user ) ) {
			return self::error( 'administrator_required', 'Accesso riservato agli amministratori.', 403 );
		}

		try {
			$tokens = Fant_Admin_API_V4_Auth::rotate( $refresh_token );
		} catch ( Throwable $exception ) {
			$tokens = null;
		}

		if ( ! $tokens ) {
			return self::error( 'invalid_refresh_token', 'Refresh token non valido o scaduto.', 401 );
		}

		return rest_ensure_response( array_merge( $tokens, array( 'user' => self::user_data( $user ) ) ) );
	}

	public static function logout( WP_REST_Request $request ): WP_REST_Response {
		$refresh_token = (string) $request->get_param( 'refreshToken' );
		if ( '' !== $refresh_token ) {
			Fant_Admin_API_V4_Auth::revoke( $refresh_token );
		}

		return new WP_REST_Response( null, 204 );
	}

	public static function me(): WP_REST_Response {
		return new WP_REST_Response( self::user_data( wp_get_current_user() ), 200 );
	}

	public static function categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return self::error( 'categories_error', 'Impossibile caricare le categorie.', 500 );
		}

		$data = array_map( array( __CLASS__, 'category_data' ), $terms );
		usort(
			$data,
			static function ( array $left, array $right ): int {
				$order = $left['menuOrder'] <=> $right['menuOrder'];
				return 0 !== $order ? $order : strcasecmp( $left['name'], $right['name'] );
			}
		);

		return rest_ensure_response( $data );
	}

	public static function create_category( WP_REST_Request $request ) {
		$name = sanitize_text_field( (string) $request->get_param( 'name' ) );
		if ( '' === $name ) {
			return self::error( 'category_name_required', 'Il nome della categoria è obbligatorio.', 422 );
		}

		$parent = max( 0, (int) $request->get_param( 'parent' ) );
		if ( $parent && ! term_exists( $parent, 'product_cat' ) ) {
			return self::error( 'invalid_category_parent', 'La categoria padre non esiste.', 422 );
		}

		$args = array(
			'parent'      => $parent,
			'description' => sanitize_textarea_field( (string) $request->get_param( 'description' ) ),
		);
		$slug = sanitize_title( (string) $request->get_param( 'slug' ) );
		if ( '' !== $slug ) {
			$args['slug'] = $slug;
		}

		$result = wp_insert_term( $name, 'product_cat', $args );
		if ( is_wp_error( $result ) ) {
			return self::term_error( $result );
		}

		$term_id = (int) $result['term_id'];
		update_term_meta( $term_id, 'display_type', self::display_type( $request->get_param( 'display' ) ) );
		update_term_meta( $term_id, 'order', self::next_category_order( $parent ) );
		self::clear_category_cache( $term_id );

		return new WP_REST_Response( self::category_data( get_term( $term_id, 'product_cat' ) ), 201 );
	}

	public static function update_category( WP_REST_Request $request ) {
		$term_id = (int) $request['categoryId'];
		$term    = get_term( $term_id, 'product_cat' );
		if ( ! $term instanceof WP_Term ) {
			return self::error( 'category_not_found', 'Categoria non trovata.', 404 );
		}

		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		$args   = array();

		if ( array_key_exists( 'name', $params ) ) {
			$name = sanitize_text_field( (string) $params['name'] );
			if ( '' === $name ) {
				return self::error( 'category_name_required', 'Il nome della categoria è obbligatorio.', 422 );
			}
			$args['name'] = $name;
		}
		if ( array_key_exists( 'slug', $params ) ) {
			$args['slug'] = sanitize_title( (string) $params['slug'] );
		}
		if ( array_key_exists( 'description', $params ) ) {
			$args['description'] = sanitize_textarea_field( (string) $params['description'] );
		}
		if ( array_key_exists( 'parent', $params ) ) {
			$parent = max( 0, (int) $params['parent'] );
			if ( $parent === $term_id || ( $parent && ! term_exists( $parent, 'product_cat' ) ) ) {
				return self::error( 'invalid_category_parent', 'Categoria padre non valida.', 422 );
			}
			if ( self::is_category_descendant( $parent, $term_id ) ) {
				return self::error( 'category_cycle', 'Non è possibile creare una gerarchia circolare.', 422 );
			}
			$args['parent'] = $parent;
		}

		if ( $args ) {
			$result = wp_update_term( $term_id, 'product_cat', $args );
			if ( is_wp_error( $result ) ) {
				return self::term_error( $result );
			}
		}
		if ( array_key_exists( 'display', $params ) ) {
			update_term_meta( $term_id, 'display_type', self::display_type( $params['display'] ) );
		}

		self::clear_category_cache( $term_id );
		return rest_ensure_response( self::category_data( get_term( $term_id, 'product_cat' ) ) );
	}

	public static function delete_category( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$term_id = (int) $request['categoryId'];
		if ( (int) get_option( 'default_product_cat' ) === $term_id ) {
			return self::error( 'default_category', 'La categoria predefinita di WooCommerce non può essere eliminata.', 409 );
		}
		if ( ! term_exists( $term_id, 'product_cat' ) ) {
			return self::error( 'category_not_found', 'Categoria non trovata.', 404 );
		}

		$result = wp_delete_term( $term_id, 'product_cat' );
		if ( is_wp_error( $result ) || false === $result ) {
			return self::error( 'category_delete_failed', 'Impossibile eliminare la categoria.', 500 );
		}
		self::clear_category_cache( $term_id );

		return new WP_REST_Response( null, 204 );
	}

	public static function reorder_categories( WP_REST_Request $request ) {
		$items = $request->get_param( 'items' );
		if ( ! is_array( $items ) || ! $items ) {
			return self::error( 'invalid_category_order', 'L’ordinamento delle categorie non è valido.', 422 );
		}

		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return self::error( 'categories_error', 'Impossibile verificare le categorie.', 500 );
		}

		$parents = array();
		foreach ( $terms as $term ) {
			$parents[ (int) $term->term_id ] = (int) $term->parent;
		}
		$normalized = array();
		foreach ( $items as $item ) {
			$id     = isset( $item['id'] ) ? (int) $item['id'] : 0;
			$parent = isset( $item['parent'] ) ? max( 0, (int) $item['parent'] ) : 0;
			if ( ! isset( $parents[ $id ] ) || ( $parent && ! isset( $parents[ $parent ] ) ) || $id === $parent ) {
				return self::error( 'invalid_category_order', 'L’ordinamento contiene categorie non valide.', 422 );
			}
			$parents[ $id ] = $parent;
			$normalized[ $id ] = array(
				'id'        => $id,
				'parent'    => $parent,
				'menuOrder' => isset( $item['menuOrder'] ) ? max( 0, (int) $item['menuOrder'] ) : 0,
			);
		}

		foreach ( array_keys( $parents ) as $id ) {
			$seen   = array();
			$cursor = $id;
			while ( $cursor && isset( $parents[ $cursor ] ) ) {
				if ( isset( $seen[ $cursor ] ) ) {
					return self::error( 'category_cycle', 'Non è possibile creare una gerarchia circolare.', 422 );
				}
				$seen[ $cursor ] = true;
				$cursor = $parents[ $cursor ];
			}
		}

		$depth = static function ( int $id ) use ( $parents ): int {
			$level = 0;
			while ( isset( $parents[ $id ] ) && $parents[ $id ] ) {
				++$level;
				$id = $parents[ $id ];
			}
			return $level;
		};
		uasort( $normalized, static fn( array $a, array $b ): int => $depth( $a['id'] ) <=> $depth( $b['id'] ) );

		foreach ( $normalized as $item ) {
			$result = wp_update_term( $item['id'], 'product_cat', array( 'parent' => $item['parent'] ) );
			if ( is_wp_error( $result ) ) {
				return self::term_error( $result );
			}
			update_term_meta( $item['id'], 'order', $item['menuOrder'] );
		}

		self::clear_category_cache();
		return self::categories();
	}

	public static function catalogs() {
		return rest_ensure_response( Fant_Admin_API_V4_Catalogs::all() );
	}

	public static function catalog( WP_REST_Request $request ) {
		return rest_ensure_response( Fant_Admin_API_V4_Catalogs::find( (string) $request['catalogCode'] ) );
	}

	public static function create_catalog( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Catalogs::create(
			(string) $request->get_param( 'codice' ),
			(string) $request->get_param( 'nome' )
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response( $result, 201 );
	}

	public static function update_catalog( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		$code   = strtolower( (string) $request['catalogCode'] );
		if ( isset( $params['codice'] ) && strtolower( trim( (string) $params['codice'] ) ) !== $code ) {
			return self::error( 'catalog_code_immutable', 'Il codice del catalogo non può essere modificato.', 409 );
		}

		return rest_ensure_response(
			Fant_Admin_API_V4_Catalogs::update( $code, (string) ( $params['nome'] ?? '' ) )
		);
	}

	public static function update_catalog_contenuto( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();

		return rest_ensure_response(
			Fant_Admin_API_V4_Catalogs::update_contenuto(
				strtolower( (string) $request['catalogCode'] ),
				$params['prodotti'] ?? null
			)
		);
	}

	public static function update_catalog_settings( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();

		return rest_ensure_response(
			Fant_Admin_API_V4_Catalogs::update_settings(
				strtolower( (string) $request['catalogCode'] ),
				$params
			)
		);
	}

	public static function delete_catalog( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Catalogs::delete( (string) $request['catalogCode'] );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response( null, 204 );
	}

	public static function covers() {
		return rest_ensure_response( Fant_Admin_API_V4_Covers::all() );
	}

	public static function cover( WP_REST_Request $request ) {
		return rest_ensure_response( Fant_Admin_API_V4_Covers::find( (string) $request['coverCode'] ) );
	}

	public static function create_cover( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Covers::create(
			(string) $request->get_param( 'codice' ),
			(string) $request->get_param( 'nome' ),
			(string) $request->get_param( 'nomeFilePdf' )
		);
		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 201 );
	}

	public static function update_cover( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		$code   = strtolower( (string) $request['coverCode'] );
		if ( isset( $params['codice'] ) && strtolower( trim( (string) $params['codice'] ) ) !== $code ) {
			return self::error( 'cover_code_immutable', 'Il codice della copertina non può essere modificato.', 409 );
		}
		return rest_ensure_response(
			Fant_Admin_API_V4_Covers::update(
				$code,
				(string) ( $params['nome'] ?? '' ),
				(string) ( $params['nomeFilePdf'] ?? '' )
			)
		);
	}

	public static function delete_cover( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Covers::delete( (string) $request['coverCode'] );
		return is_wp_error( $result ) ? $result : new WP_REST_Response( null, 204 );
	}

	public static function upload_cover_attachments( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Covers::upload_attachments( (string) $request['coverCode'], $request->get_file_params() );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function update_cover_attachment( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		return rest_ensure_response(
			Fant_Admin_API_V4_Covers::update_attachment(
				(string) $request['coverCode'],
				rawurldecode( (string) $request['fileName'] ),
				(string) ( $params['alias'] ?? '' )
			)
		);
	}

	public static function delete_cover_attachment( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Covers::delete_attachment(
			(string) $request['coverCode'],
			rawurldecode( (string) $request['fileName'] )
		);
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function update_cover_articoli( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		return rest_ensure_response(
			Fant_Admin_API_V4_Covers::update_articoli(
				(string) $request['coverCode'],
				$params['articoli'] ?? null
			)
		);
	}

	public static function cover_pdf( WP_REST_Request $request ) {
		$result = Fant_Admin_API_V4_Covers::pdf( (string) $request['coverCode'] );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function layouts() {
		return rest_ensure_response( Fant_Admin_API_V4_Layouts::all() );
	}

	public static function layout( WP_REST_Request $request ) {
		return rest_ensure_response( Fant_Admin_API_V4_Layouts::find( (string) $request['layoutCode'] ) );
	}

	public static function update_layout( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();

		return rest_ensure_response(
			Fant_Admin_API_V4_Layouts::update(
				(string) $request['layoutCode'],
				$params
			)
		);
	}

	public static function products( WP_REST_Request $request ) {
		$category_id = (int) $request->get_param( 'categoryId' );
		if ( $category_id > 0 ) {
			$include = ! in_array( strtolower( (string) $request->get_param( 'includeChildren' ) ), array( '0', 'false' ), true );
			return rest_ensure_response( Fant_Admin_API_V4_Products::by_category( $category_id, $include ) );
		}
		return rest_ensure_response(
			Fant_Admin_API_V4_Products::search(
				(string) $request->get_param( 'search' ),
				(int) ( $request->get_param( 'page' ) ?: 1 ),
				(int) ( $request->get_param( 'perPage' ) ?: 20 )
			)
		);
	}

	public static function ai_settings(): WP_REST_Response {
		return new WP_REST_Response( Fant_Admin_API_V4_AI_Settings::get_public(), 200 );
	}

	public static function update_ai_settings( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		$result = Fant_Admin_API_V4_AI_Settings::update( $params );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	private static function user_data( WP_User $user ): array {
		return array(
			'id'          => (int) $user->ID,
			'username'    => $user->user_login,
			'email'       => $user->user_email,
			'displayName' => $user->display_name,
			'firstName'   => $user->first_name,
			'lastName'    => $user->last_name,
			'roles'       => array_values( (array) $user->roles ),
			'avatarUrl'   => get_avatar_url( $user->ID, array( 'size' => 96 ) ),
		);
	}

	private static function category_data( WP_Term $term ): array {
		$image_id  = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
		$image_src = $image_id ? wp_get_attachment_image_url( $image_id, 'full' ) : false;

		return array(
			'id'          => (int) $term->term_id,
			'name'        => $term->name,
			'slug'        => $term->slug,
			'description' => $term->description,
			'parent'      => (int) $term->parent,
			'display'     => (string) get_term_meta( $term->term_id, 'display_type', true ),
			'image'       => $image_src ? array(
				'id'  => $image_id,
				'src' => $image_src,
				'alt' => (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
			) : null,
			'count'       => (int) $term->count,
			'menuOrder'   => (int) get_term_meta( $term->term_id, 'order', true ),
		);
	}

	private static function next_category_order( int $parent ): int {
		$children = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'parent'     => $parent,
				'fields'     => 'ids',
			)
		);
		if ( is_wp_error( $children ) || ! $children ) {
			return 0;
		}

		$orders = array_map( static fn( $id ): int => (int) get_term_meta( $id, 'order', true ), $children );
		return max( $orders ) + 1;
	}

	private static function display_type( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( '', 'products', 'subcategories', 'both' ), true ) ? $value : '';
	}

	private static function is_category_descendant( int $candidate, int $ancestor ): bool {
		while ( $candidate ) {
			if ( $candidate === $ancestor ) {
				return true;
			}
			$term = get_term( $candidate, 'product_cat' );
			if ( ! $term instanceof WP_Term ) {
				return false;
			}
			$candidate = (int) $term->parent;
		}
		return false;
	}

	private static function clear_category_cache( int $term_id = 0 ): void {
		if ( $term_id ) {
			clean_term_cache( $term_id, 'product_cat' );
		} else {
			clean_taxonomy_cache( 'product_cat' );
		}
		if ( function_exists( 'wc_delete_product_transients' ) ) {
			wc_delete_product_transients();
		}
	}

	private static function term_error( WP_Error $error ): WP_Error {
		$status = 'term_exists' === $error->get_error_code() ? 409 : 422;
		return self::error( $error->get_error_code(), $error->get_error_message(), $status );
	}

	private static function rate_limit_key( string $login ): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		return 'faa_login_' . md5( strtolower( $login ) . '|' . $ip );
	}

	private static function error( string $code, string $message, int $status ): WP_Error {
		return new WP_Error( $code, $message, array( 'status' => $status ) );
	}
}
